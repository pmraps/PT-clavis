Spanish Dictionary for Addict Spell Check

Initially Developed by D C AL CODA.

Additional words from Fabio A. Ardila M and from TimeMaker http://www.timemaker.org

Dictionary for use with Addict Spell Check & Thesaurus v3 and 4
Copyright (c)1997-2010 Addictive Software

http://www.addictivesoftware.com/
mailto:support@addictivesoftware.com

This dictionary is made freely available to all users of Addictive 
Software's Addict Spell Check & Thesaurus v3 (it will not work with 
earlier versions of Addict). 

No guarantees are made as to the accuracy or reliability of this 
dictionary, but we would encourage you to notify us of any problems 
your find or additions you would like to see.

Addictive Software and support are native English speakers and we
are reliant on third party sources for information regarding the
quality of non-English dictionaries.

You are permitted to distribute this dictionary with your application
provided you do not charge for the dictionary itself.

http://www.addictivesoftware.com/
mailto:support@addictivesoftware.com

